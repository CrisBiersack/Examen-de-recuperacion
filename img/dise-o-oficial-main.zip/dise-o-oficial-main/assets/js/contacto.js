//Envio Formulario Contacto
if (typeof config === 'undefined') {
    console.error("El archivo de configuración no se cargó correctamente.");
} else {
    // Inicializa EmailJS con la API key
    emailjs.init(config.apiKey);
}
    const btn = document.getElementById('button-contacto');

    document.getElementById('form')
    .addEventListener('submit', function(event) {
    event.preventDefault();

    

    const serviceID = 'default_service';
    const templateID = config.templateContactKey;

    emailjs.sendForm(serviceID, templateID, this)
        .then(() => {

            Swal.fire({
                icon: 'success',
                title: 'Se envió el mensaje',
                timer: 2500,
                showConfirmButton: false
              })

        window.location = "contacto.html";

        }, (err) => {
        btn.value = 'Send Email';
        alert(JSON.stringify(err));
        });
    });

    document.getElementById("form").addEventListener("submit", function(event) {
        event.preventDefault(); // Evita el envío tradicional del formulario
      
        // Captura los valores de los campos
        const nombre = document.getElementById("nombre").value;
        const correo = document.getElementById("correo").value;
        const celular = document.getElementById("celular").value;
        const mensaje = document.querySelector("textarea[name='mensaje']").value;
      
        // Verifica si los campos están completos (opcional si el 'required' ya está en el HTML)
        if (nombre && correo && celular && mensaje) {
          // Muestra el mensaje de agradecimiento con SweetAlert2
          Swal.fire({
            title: "¡Gracias por contactarnos!",
            text: "Esperamos serle de ayuda.",
            icon: "success",
            confirmButtonText: "Cerrar"
          });
      
          // Limpia el formulario
          document.getElementById("form").reset();
        }
      });
      
